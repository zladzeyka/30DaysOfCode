import UIKit

var str = "Hello, playground"

//Day 1
var i = 4
var d = 4.0
var s = "HackerRank "
// Declare second integer, double, and String variables.
var a: Int
var b : Double
var c : String
// Read and save an integer, double, and String to your variables.
a = Int(readLine()!) ?? 0
b = Double(readLine()!) ?? 0.0
c = readLine()!
// Print the sum of both integer variables on a new line.
print (i + a)
// Print the sum of the double variables on a new line.
let sum = d + b
print (Double(d) + Double(b))
// Concatenate and print the String variables on a new line
print (s + c)
// The 's' variable above should be printed first.

